
n1 = float(input("Digite um numero: "))
n2 = float(input("Digite um outro: "))
soma = n1 + n2
subtracao = n1 - n2
divisao = n1 / n2
multiplicacao = n1 * n2

print(str(n1) + " + " + str(n2) + " = " + str(soma))
print(str(n1) + " - " + str(n2) + " = " + str(subtracao))
print(str(n1) + " / " + str(n2) + " = " + str(divisao))
print(str(n1) + " * " + str(n2) + " = " + str(multiplicacao))

input("Pressione algo para sair...")