# Photon parser
# This script converts lines of photon code into tokens
# and also generates the struct of the code.
# This struct is used by the Engine to execute the code.

def parse():
    pass

def assembly():
    pass
